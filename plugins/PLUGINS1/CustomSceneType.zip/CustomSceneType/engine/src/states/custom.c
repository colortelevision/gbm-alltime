#pragma bank 255

#include "data/states_defines.h"
#include "states/custom.h"

#include "actor.h"
#include "camera.h"
#include "data_manager.h"
#include "game_time.h"
#include "input.h"
#include "math.h"
#include "vm.h"

void custom_init(void) BANKED
{
}

void custom_update(void) BANKED
{
}
