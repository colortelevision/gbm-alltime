#ifndef STATE_CUSTOM_H
#define STATE_CUSTOM_H

#include <gbdk/platform.h>

void custom_init(void) BANKED;
void custom_update(void) BANKED;

#endif
