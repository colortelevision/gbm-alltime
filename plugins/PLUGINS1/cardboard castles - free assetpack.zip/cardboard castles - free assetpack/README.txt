
--- THANK U -----------------

Thank you for downloading this Cardboard Castles asset pack :) hope you like it and find it usefull
This project was born as a fun little project, following the cardboard boxes. It won't recieve future updates.
In the near future i'm planing to ad a color version. As an extension to Tiny Blocks asset pack.
follow me on itch.io to see the updates. @danimaccari -> https://dani-maccari.itch.io/


--- HOW TO USE --------------

The pack contains 60 tiles. 18x18 pixels each box

Box specifications:
	each box is 10 pixels tall
	the base is 16p width x 9p height
	each lateral face is 8p width x 10p height


--- LICENSE ----------------

This pack is free for personal or comercial use as long as it's atributed to DANI MACCARI.
You may not repackage, redistribute or resell the assets, no matter how much they are modified. - This includes NFTs.